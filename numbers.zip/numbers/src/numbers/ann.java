package numbers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ann {
	static String result ="";
	static ArrayList<perceptron> i_layer =new ArrayList<perceptron>();
	static ArrayList<Integer> answer =new ArrayList<Integer>();
	static ArrayList<perceptron> h1 = new ArrayList<perceptron>();
	static ArrayList<perceptron> o_layer = new ArrayList<perceptron>();
	
	private static int hidden1 =256;
	private static int i_num = 784;
	private static int a_num = 10;
	static ArrayList<String[]> numb = new ArrayList<String[]>();

	public static void execute(String st) throws IOException{

		init();
		test(st);
		//test1();
		//get input from buttons, and then test with the trained model.
	}

	
	//for the initialize the model.make perceptrons for input, hidden, output layer, and set weights for each layer.
	private static void init() {
		//Input perceptrons.
		for (int i=0;i<i_num;i++) {
			i_layer.add(new perceptron());
		}
		//
		//The perceptrons in the input layer hold weights(from input to hidden layer) value. 
        String line = "";
        BufferedReader bufReader = null;

		try{
			String path = ann.class.getResource("").getPath(); 
            File file = new File(path + "test.txt");
            FileReader FR = new FileReader(file);
            bufReader = new BufferedReader(FR);
            while ( (line = bufReader.readLine())!= null){
            	String[] hi = line.split(",");
            	numb.add(hi);
            }
            bufReader.close();
        }catch (FileNotFoundException e) {
        }catch(IOException e){
            System.out.println(e);
        }
		
		// makes perceptrons, and initialize the weights. 
		for (int i =0 ; i<i_num; i++) {
			i_layer.get(i).change_weight(numb.get(i));
		}
		
		
		//layer2 (hidden perceptrons)
		for (int i=0 ;i<hidden1+1;i++) {
			h1.add(new perceptron());
		}
		//bias
		//h1.get(hidden1).set_output(1);

		for (int i =i_num ; i< hidden1 + i_num; i++) {
			h1.get(i-i_num).change_weight(numb.get(i));
			}
	
		
		//output layer
		for (int i=0 ;i<a_num;i++) {
			o_layer.add(new perceptron());
		}
	}	
	
	
	//proceed forward propagation, and then shows cross entropy error
	private static void forward() {
		// Calculate values of perceptrons in the layer 2. and then save that value into each perceptrons.
		float temp =0;
		
		for (int j=0; j<hidden1 ;j++) {
			temp = 0;
			for (int i =0 ; i<i_num; i++) {
				//calculate all values for h1, and then save in temp variable,
				temp = temp + i_layer.get(i).get_weight(j)*i_layer.get(i).get_output();
		}
			//set each perceptron's value (= temp value)
			//it is just total value, not logistic(total value). logistic function is conducted when .get_output() function is called. 
			h1.get(j).set_output(temp);
		}
		

		for (int j=0; j<a_num ;j++) {
			temp = 0;
			
			for (int i =0 ; i<hidden1; i++) {
				//calculate all values for h1, and then save in temp variable,


				temp = temp + h1.get(i).get_weight(j)*h1.get(i).get_output();

		}

			//set each perceptron's value (= temp value)
			//it is just total value, not logistic(total value). logistic function is conducted when .get_output() function is called.
			o_layer.get(j).set_output(temp);
		}

		//calculate errors using softmax and cross entropy error.
		softmax();
	}
	
	//The explanation is in the "softmax and cross entropy error" text file.
	private static void softmax() {
		//float soft = Float.MIN_VALUE; --> wrong, because this returns the smallest positive value..!!! 
		// to get minimum 'negative' float value
		float output_max = -Float.MAX_VALUE;
		
		//find the highest number.
		for(int s=0;s<a_num;s++) {
			if (o_layer.get(s).get_total() > output_max) {
				output_max = o_layer.get(s).get_total();
			}
		}	

		//subtract,(to prevent from having too big number) and set e value for each perceptrons in the output layer.
		for(int s=0;s<a_num;s++) {
			o_layer.get(s).set_e((float) Math.exp(o_layer.get(s).get_total() - output_max));
		}
		
		// for the denominator
		float soft_total =0;
		for(int s=0;s<a_num;s++) {
			soft_total = soft_total + o_layer.get(s).get_e();
		}
		
		//set probability for each class.
		for(int s=0;s<a_num;s++) {
			o_layer.get(s).set_prob(o_layer.get(s).get_e()/soft_total);
		}
		
	}
	//change the weight based on the error and derivative.

	 // getting input from the buttons, and then change it to "0101.." string information

	private static void test1() {
        ArrayList<String[]> n = new ArrayList<String[]>();

		//get a input from argument. The input is a string which consists of 35 characters.
		try{

        File file = new File("C:\\Users\\21500\\eclipse-workspace\\ann\\src\\ann\\mnist_test1.csv");
        FileReader FR = new FileReader(file);
        BufferedReader bufReader = new BufferedReader(FR);
        String line;
        for (int a =0; a<10000; a++){
            line = bufReader.readLine();
        	String[] h = line.split(",");
        	n.add(h);

        }
        bufReader.close();
    }catch (FileNotFoundException e) {
    }catch(IOException e){
        System.out.println(e);
    }
	float correct = 0;
	for ( int j=0 ; j < n.size();j++) {
		
		for (int i =0;i<i_num;i++) {
			
			if (Integer.valueOf(n.get(j)[i+1])>240) {
				i_layer.get(i).input_layer(1);
			}else {
				i_layer.get(i).input_layer(0);
			}			}
			forward();

			float w = 0;
			int index=0;
			// find out the class which has the highest probability. 
			for (int j1 =0 ; j1<a_num;j1++) {
				if (w<o_layer.get(j1).get_prob()) {
					w = o_layer.get(j1).get_prob();
					index= j1;
				}
			}
			
			//result..
			//String result = "Estimation: " + index+ " probability " + output.get(index).get_prob() + "correct answer: "+ n.get(j)[0];
			//System.out.println(result);
			
			if (index == Integer.valueOf(n.get(j)[0])) {
				correct++;
			}
			
			
		}
	System.out.println((float)(correct/n.size()));
	
	}
	

	//test
	private static void test(String a) {
		String n = a;		
		for (int i =0;i<i_num;i++) {
			i_layer.get(i).input_layer(n.charAt(i)-'0');

		}

			
			forward();

			float w = 0;
			int index=0;
			// find out the class which has the highest probability. 
			for (int j1 =0 ; j1<a_num;j1++) {
				if (w<o_layer.get(j1).get_prob()) {
					w = o_layer.get(j1).get_prob();
					index= j1;
				}
			}
			
			//result..
			result = "Estimation: " + index +"\n ";
			
		}	
	}
